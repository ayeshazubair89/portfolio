package com.example.portfolioapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
