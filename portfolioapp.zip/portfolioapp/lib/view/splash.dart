import 'dart:async';

import 'package:flutter/material.dart';

import 'intro.dart';

class splash extends StatefulWidget {
  const splash({super.key});

  @override
  State<splash> createState() => _splashState();
}

class _splashState extends State<splash> {
  @override
  void initState(){
    super.initState();
    Timer(const Duration(seconds: 5),
            () => Navigator.push(context,MaterialPageRoute(builder: (context)=> intro())
        ));
  }

  Widget build(BuildContext context) {
    final height=MediaQuery.of(context).size.height*1;
    final width=MediaQuery.of(context).size.width*1;
    return Scaffold(
      body:   Expanded(
        child:
        Expanded(
          child: Container( height: height*1,
            width: width*1,
            decoration: BoxDecoration(/*color: Colors.brown.shade900,*/
                image: DecorationImage(
                    image: AssetImage('assets/images/hts.jpeg'),fit: BoxFit.fitWidth)
          
            ),

              child: Container(
                height: height*1,
                        width: width*1,
                        decoration: BoxDecoration(/*color: Colors.black54,*/
                        ),
               child:  Column(
                  // mainAxisAlignment: MainAxisAlignment.center,crossAxisAlignment: CrossAxisAlignment.start,
                   children: [
                     Padding(
                       padding: const EdgeInsets.only(top:200,left:0),
                       child: Text("P O R T F O L I O , ",style: TextStyle(
                           fontSize:40,fontWeight: FontWeight.bold,color:Colors.brown.shade900),),
                     )
                     ,


                     Padding(
                       padding: const EdgeInsets.only(top:20),
                       child: Text("AYESHA ZUBAIR !",style:
                       TextStyle(fontSize:25,fontWeight: FontWeight.bold,color: Colors.white30),),
                     ),
                   /*  Padding(
                       padding: const EdgeInsets.only(top:240,left:0),
                       child: Text("P O R T F O L I O, ",style: TextStyle(
                           fontSize:40,fontWeight: FontWeight.bold,color:Colors.brown.shade900),),
                     )
                     ,


                     Padding(
                       padding: const EdgeInsets.only(left:150,top:150),
                       child: Text("AYESHA ZUBAIR !",style:
                       TextStyle(fontSize:25,fontWeight: FontWeight.bold,color: Colors.white),),
                     ),*/
          
                   ],
                 ),
          
              ),

          ),
        ),
      ),
    );
  }
}
