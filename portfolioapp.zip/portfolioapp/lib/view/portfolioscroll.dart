import 'package:flutter/material.dart';

class portfolioscroll extends StatelessWidget {
  const portfolioscroll({super.key});

  @override
  Widget build(BuildContext context) {
    final height=MediaQuery.of(context).size.height*1;
    final width=MediaQuery.of(context).size.width*1;

    return Scaffold(
      appBar: AppBar(
        title: Text("Portfolio Showcase",style: TextStyle(color: Colors.white,fontWeight: FontWeight.w900),),
        centerTitle: true,
        backgroundColor: Colors.brown.shade900,

        /*actions: [
          Padding(
            padding: const EdgeInsets.only(right: 30.0),
            child: Container(
              width: 30,
              child: Image.asset(
                'assets/images/pic.png',
              ),
            ),
          ),
        ],*/
      ),
      body: SingleChildScrollView(
        scrollDirection: Axis.vertical,

        child:  Center(
          child: Container(
            decoration: BoxDecoration(color: Colors.brown.shade100),
            child: Center(
              child: Row(
                children:[
                  SingleChildScrollView(
                    scrollDirection: Axis.vertical,
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Column(
                        children: [
                          Container(
                          margin: EdgeInsets.only(top: 10),
                          height: height*0.4,
                          width: width*0.45,
                          decoration: BoxDecoration(
                              color: Colors.brown.shade100,
                              borderRadius: BorderRadius.circular(15),
                              boxShadow: [
                                BoxShadow(color: Colors.brown.shade800,
                                  offset: const Offset(4.0, 4.0),
                                  blurRadius: 15,
                                  spreadRadius: 1.0,
                                ),
                                const   BoxShadow(color: Colors.white,
                                  offset: const Offset(-4.0, -4.0),
                                  blurRadius: 15,
                                  spreadRadius: 1.0,
                                ),

                              ]

                          ),

                          child: Padding(
                            padding: const EdgeInsets.all(5.0),
                            child: ClipRRect(
                              borderRadius: BorderRadius.circular(15.0), // Yahan aap apni pasandeeda radius ko set kar sakte hain.
                              child: Image.asset("assets/images/s1.png"),
                            )
                          ),

                                      ),
                          Container(
                            margin: EdgeInsets.only(top: 10),
                            height: height*0.3,
                            width: width*0.4,
                            decoration: BoxDecoration(
                                color: Colors.brown.shade100,
                                borderRadius: BorderRadius.circular(15),
                                boxShadow: [
                                  BoxShadow(color: Colors.brown.shade800,
                                    offset: const Offset(4.0, 4.0),
                                    blurRadius: 15,
                                    spreadRadius: 1.0,
                                  ),
                                  const   BoxShadow(color: Colors.white,
                                    offset: const Offset(-4.0, -4.0),
                                    blurRadius: 15,
                                    spreadRadius: 1.0,
                                  ),

                                ]

                            ),

                            child: Padding(
                                padding: const EdgeInsets.all(5.0),
                                child: ClipRRect(
                                  borderRadius: BorderRadius.circular(15.0), // Yahan aap apni pasandeeda radius ko set kar sakte hain.
                                  child: Image.asset("assets/images/s2.png"),
                                )
                            ),

                          ),
                          Container(
                            margin: EdgeInsets.only(top: 10),
                            height: height*0.4,
                            width: width*0.45,
                            decoration: BoxDecoration(
                                color: Colors.brown.shade100,
                                borderRadius: BorderRadius.circular(15),
                                boxShadow: [
                                  BoxShadow(color: Colors.brown.shade800,
                                    offset: const Offset(4.0, 4.0),
                                    blurRadius: 15,
                                    spreadRadius: 1.0,
                                  ),
                                  const   BoxShadow(color: Colors.white,
                                    offset: const Offset(-4.0, -4.0),
                                    blurRadius: 15,
                                    spreadRadius: 1.0,
                                  ),

                                ]

                            ),

                            child: Padding(
                                padding: const EdgeInsets.all(5.0),
                                child: ClipRRect(
                                  borderRadius: BorderRadius.circular(15.0), // Yahan aap apni pasandeeda radius ko set kar sakte hain.
                                  child: Image.asset("assets/images/s3.png"),
                                )
                            ),

                          ),
                          Container(
                            margin: EdgeInsets.only(top: 10),
                            height: height*0.3,
                            width: width*0.4,
                            decoration: BoxDecoration(
                                color: Colors.brown.shade100,
                                borderRadius: BorderRadius.circular(15),
                                boxShadow: [
                                  BoxShadow(color: Colors.brown.shade800,
                                    offset: const Offset(4.0, 4.0),
                                    blurRadius: 15,
                                    spreadRadius: 1.0,
                                  ),
                                  const   BoxShadow(color: Colors.white,
                                    offset: const Offset(-4.0, -4.0),
                                    blurRadius: 15,
                                    spreadRadius: 1.0,
                                  ),

                                ]

                            ),

                            child: Padding(
                                padding: const EdgeInsets.all(5.0),
                                child: ClipRRect(
                                  borderRadius: BorderRadius.circular(15.0), // Yahan aap apni pasandeeda radius ko set kar sakte hain.
                                  child: Image.asset("assets/images/s4.png"),
                                )
                            ),

                          ),
                          Container(
                            margin: EdgeInsets.only(top: 10),
                            height: height*0.4,
                            width: width*0.45,
                            decoration: BoxDecoration(
                                color: Colors.brown.shade100,
                                borderRadius: BorderRadius.circular(15),
                                boxShadow: [
                                  BoxShadow(color: Colors.brown.shade800,
                                    offset: const Offset(4.0, 4.0),
                                    blurRadius: 15,
                                    spreadRadius: 1.0,
                                  ),
                                  const   BoxShadow(color: Colors.white,
                                    offset: const Offset(-4.0, -4.0),
                                    blurRadius: 15,
                                    spreadRadius: 1.0,
                                  ),

                                ]

                            ),

                            child: Padding(
                                padding: const EdgeInsets.all(5.0),
                                child: ClipRRect(
                                  borderRadius: BorderRadius.circular(15.0), // Yahan aap apni pasandeeda radius ko set kar sakte hain.
                                  child: Image.asset("assets/images/s10.png"),
                                )
                            ),

                          ),
                          Container(
                            margin: EdgeInsets.only(top: 10),
                            height: height*0.3,
                            width: width*0.4,
                            decoration: BoxDecoration(
                                color: Colors.brown.shade100,
                                borderRadius: BorderRadius.circular(15),
                                boxShadow: [
                                  BoxShadow(color: Colors.brown.shade800,
                                    offset: const Offset(4.0, 4.0),
                                    blurRadius: 15,
                                    spreadRadius: 1.0,
                                  ),
                                  const   BoxShadow(color: Colors.white,
                                    offset: const Offset(-4.0, -4.0),
                                    blurRadius: 15,
                                    spreadRadius: 1.0,
                                  ),

                                ]

                            ),

                            child: Padding(
                                padding: const EdgeInsets.all(5.0),
                                child: ClipRRect(
                                  borderRadius: BorderRadius.circular(15.0), // Yahan aap apni pasandeeda radius ko set kar sakte hain.
                                  child: Image.asset("assets/images/p1.png"),
                                )
                            ),

                          ),
                          Container(
                            margin: EdgeInsets.only(top: 10),
                            height: height*0.4,
                            width: width*0.45,
                            decoration: BoxDecoration(
                                color: Colors.brown.shade100,
                                borderRadius: BorderRadius.circular(15),
                                boxShadow: [
                                  BoxShadow(color: Colors.brown.shade800,
                                    offset: const Offset(4.0, 4.0),
                                    blurRadius: 15,
                                    spreadRadius: 1.0,
                                  ),
                                  const   BoxShadow(color: Colors.white,
                                    offset: const Offset(-4.0, -4.0),
                                    blurRadius: 15,
                                    spreadRadius: 1.0,
                                  ),

                                ]

                            ),

                            child: Padding(
                                padding: const EdgeInsets.all(5.0),
                                child: ClipRRect(
                                  borderRadius: BorderRadius.circular(15.0), // Yahan aap apni pasandeeda radius ko set kar sakte hain.
                                  child: Image.asset("assets/images/p2.png"),
                                )
                            ),

                          ),
                          Container(
                            margin: EdgeInsets.only(top: 10),
                            height: height*0.3,
                            width: width*0.4,
                            decoration: BoxDecoration(
                                color: Colors.brown.shade100,
                                borderRadius: BorderRadius.circular(15),
                                boxShadow: [
                                  BoxShadow(color: Colors.brown.shade800,
                                    offset: const Offset(4.0, 4.0),
                                    blurRadius: 15,
                                    spreadRadius: 1.0,
                                  ),
                                  const   BoxShadow(color: Colors.white,
                                    offset: const Offset(-4.0, -4.0),
                                    blurRadius: 15,
                                    spreadRadius: 1.0,
                                  ),

                                ]

                            ),

                            child: Padding(
                                padding: const EdgeInsets.all(5.0),
                                child: ClipRRect(
                                  borderRadius: BorderRadius.circular(15.0), // Yahan aap apni pasandeeda radius ko set kar sakte hain.
                                  child: Image.asset("assets/images/p3.png"),
                                )
                            ),

                          ),
                          Container(
                            margin: EdgeInsets.only(top: 10),
                            height: height*0.4,
                            width: width*0.45,
                            decoration: BoxDecoration(
                                color: Colors.brown.shade100,
                                borderRadius: BorderRadius.circular(15),
                                boxShadow: [
                                  BoxShadow(color: Colors.brown.shade800,
                                    offset: const Offset(4.0, 4.0),
                                    blurRadius: 15,
                                    spreadRadius: 1.0,
                                  ),
                                  const   BoxShadow(color: Colors.white,
                                    offset: const Offset(-4.0, -4.0),
                                    blurRadius: 15,
                                    spreadRadius: 1.0,
                                  ),

                                ]

                            ),

                            child: Padding(
                                padding: const EdgeInsets.all(5.0),
                                child: ClipRRect(
                                  borderRadius: BorderRadius.circular(15.0), // Yahan aap apni pasandeeda radius ko set kar sakte hain.
                                  child: Image.asset("assets/images/p12.png"),
                                )
                            ),

                          ),
                          Container(
                            margin: EdgeInsets.only(top: 10),
                            height: height*0.3,
                            width: width*0.4,
                            decoration: BoxDecoration(
                                color: Colors.brown.shade100,
                                borderRadius: BorderRadius.circular(15),
                                boxShadow: [
                                  BoxShadow(color: Colors.brown.shade800,
                                    offset: const Offset(4.0, 4.0),
                                    blurRadius: 15,
                                    spreadRadius: 1.0,
                                  ),
                                  const   BoxShadow(color: Colors.white,
                                    offset: const Offset(-4.0, -4.0),
                                    blurRadius: 15,
                                    spreadRadius: 1.0,
                                  ),

                                ]

                            ),

                            child: Padding(
                                padding: const EdgeInsets.all(5.0),
                                child: ClipRRect(
                                  borderRadius: BorderRadius.circular(15.0), // Yahan aap apni pasandeeda radius ko set kar sakte hain.
                                  child: Image.asset("assets/images/1a.png"),
                                )
                            ),

                          ),
                          Container(
                            margin: EdgeInsets.only(top: 10),
                            height: height*0.4,
                            width: width*0.45,
                            decoration: BoxDecoration(
                                color: Colors.brown.shade100,
                                borderRadius: BorderRadius.circular(15),
                                boxShadow: [
                                  BoxShadow(color: Colors.brown.shade800,
                                    offset: const Offset(4.0, 4.0),
                                    blurRadius: 15,
                                    spreadRadius: 1.0,
                                  ),
                                  const   BoxShadow(color: Colors.white,
                                    offset: const Offset(-4.0, -4.0),
                                    blurRadius: 15,
                                    spreadRadius: 1.0,
                                  ),

                                ]

                            ),

                            child: Padding(
                                padding: const EdgeInsets.all(5.0),
                                child: ClipRRect(
                                  borderRadius: BorderRadius.circular(15.0), // Yahan aap apni pasandeeda radius ko set kar sakte hain.
                                  child: Image.asset("assets/images/2a.png"),
                                )
                            ),

                          ),
                          Container(
                            margin: EdgeInsets.only(top: 10),
                            height: height*0.3,
                            width: width*0.4,
                            decoration: BoxDecoration(
                                color: Colors.brown.shade100,
                                borderRadius: BorderRadius.circular(15),
                                boxShadow: [
                                  BoxShadow(color: Colors.brown.shade800,
                                    offset: const Offset(4.0, 4.0),
                                    blurRadius: 15,
                                    spreadRadius: 1.0,
                                  ),
                                  const   BoxShadow(color: Colors.white,
                                    offset: const Offset(-4.0, -4.0),
                                    blurRadius: 15,
                                    spreadRadius: 1.0,
                                  ),

                                ]

                            ),

                            child: Padding(
                                padding: const EdgeInsets.all(5.0),
                                child: ClipRRect(
                                  borderRadius: BorderRadius.circular(15.0), // Yahan aap apni pasandeeda radius ko set kar sakte hain.
                                  child: Image.asset("assets/images/3a.png"),
                                )
                            ),

                          ),
                          Container(
                            margin: EdgeInsets.only(top: 10),
                            height: height*0.4,
                            width: width*0.45,
                            decoration: BoxDecoration(
                                color: Colors.brown.shade100,
                                borderRadius: BorderRadius.circular(15),
                                boxShadow: [
                                  BoxShadow(color: Colors.brown.shade800,
                                    offset: const Offset(4.0, 4.0),
                                    blurRadius: 15,
                                    spreadRadius: 1.0,
                                  ),
                                  const   BoxShadow(color: Colors.white,
                                    offset: const Offset(-4.0, -4.0),
                                    blurRadius: 15,
                                    spreadRadius: 1.0,
                                  ),

                                ]

                            ),

                            child: Padding(
                                padding: const EdgeInsets.all(5.0),
                                child: ClipRRect(
                                  borderRadius: BorderRadius.circular(15.0), // Yahan aap apni pasandeeda radius ko set kar sakte hain.
                                  child: Image.asset("assets/images/4a.png"),
                                )
                            ),

                          ),
                          Container(
                            margin: EdgeInsets.only(top: 10),
                            height: height*0.3,
                            width: width*0.4,
                            decoration: BoxDecoration(
                                color: Colors.brown.shade100,
                                borderRadius: BorderRadius.circular(15),
                                boxShadow: [
                                  BoxShadow(color: Colors.brown.shade800,
                                    offset: const Offset(4.0, 4.0),
                                    blurRadius: 15,
                                    spreadRadius: 1.0,
                                  ),
                                  const   BoxShadow(color: Colors.white,
                                    offset: const Offset(-4.0, -4.0),
                                    blurRadius: 15,
                                    spreadRadius: 1.0,
                                  ),

                                ]

                            ),

                            child: Padding(
                                padding: const EdgeInsets.all(5.0),
                                child: ClipRRect(
                                  borderRadius: BorderRadius.circular(15.0), // Yahan aap apni pasandeeda radius ko set kar sakte hain.
                                  child: Image.asset("assets/images/5a.png"),
                                )
                            ),

                          ),
                          Container(
                            margin: EdgeInsets.only(top: 10),
                            height: height*0.4,
                            width: width*0.45,
                            decoration: BoxDecoration(
                                color: Colors.brown.shade100,
                                borderRadius: BorderRadius.circular(15),
                                boxShadow: [
                                  BoxShadow(color: Colors.brown.shade800,
                                    offset: const Offset(4.0, 4.0),
                                    blurRadius: 15,
                                    spreadRadius: 1.0,
                                  ),
                                  const   BoxShadow(color: Colors.white,
                                    offset: const Offset(-4.0, -4.0),
                                    blurRadius: 15,
                                    spreadRadius: 1.0,
                                  ),

                                ]

                            ),

                            child: Padding(
                                padding: const EdgeInsets.all(5.0),
                                child: ClipRRect(
                                  borderRadius: BorderRadius.circular(15.0), // Yahan aap apni pasandeeda radius ko set kar sakte hain.
                                  child: Image.asset("assets/images/6a.png"),
                                )
                            ),

                          ),
                          Container(
                            margin: EdgeInsets.only(top: 10),
                            height: height*0.3,
                            width: width*0.4,
                            decoration: BoxDecoration(
                                color: Colors.brown.shade100,
                                borderRadius: BorderRadius.circular(15),
                                boxShadow: [
                                  BoxShadow(color: Colors.brown.shade800,
                                    offset: const Offset(4.0, 4.0),
                                    blurRadius: 15,
                                    spreadRadius: 1.0,
                                  ),
                                  const   BoxShadow(color: Colors.white,
                                    offset: const Offset(-4.0, -4.0),
                                    blurRadius: 15,
                                    spreadRadius: 1.0,
                                  ),

                                ]

                            ),

                            child: Padding(
                                padding: const EdgeInsets.all(5.0),
                                child: ClipRRect(
                                  borderRadius: BorderRadius.circular(15.0), // Yahan aap apni pasandeeda radius ko set kar sakte hain.
                                  child: Image.asset("assets/images/7a.png"),
                                )
                            ),

                          ),
                          Container(
                            margin: EdgeInsets.only(top: 10),
                            height: height*0.4,
                            width: width*0.45,
                            decoration: BoxDecoration(
                                color: Colors.brown.shade100,
                                borderRadius: BorderRadius.circular(15),
                                boxShadow: [
                                  BoxShadow(color: Colors.brown.shade800,
                                    offset: const Offset(4.0, 4.0),
                                    blurRadius: 15,
                                    spreadRadius: 1.0,
                                  ),
                                  const   BoxShadow(color: Colors.white,
                                    offset: const Offset(-4.0, -4.0),
                                    blurRadius: 15,
                                    spreadRadius: 1.0,
                                  ),

                                ]

                            ),

                            child: Padding(
                                padding: const EdgeInsets.all(5.0),
                                child: ClipRRect(
                                  borderRadius: BorderRadius.circular(15.0), // Yahan aap apni pasandeeda radius ko set kar sakte hain.
                                  child: Image.asset("assets/images/r6.png"),
                                )
                            ),

                          ),
                          Container(
                            margin: EdgeInsets.only(top: 10),
                            height: height*0.3,
                            width: width*0.4,
                            decoration: BoxDecoration(
                                color: Colors.brown.shade100,
                                borderRadius: BorderRadius.circular(15),
                                boxShadow: [
                                  BoxShadow(color: Colors.brown.shade800,
                                    offset: const Offset(4.0, 4.0),
                                    blurRadius: 15,
                                    spreadRadius: 1.0,
                                  ),
                                  const   BoxShadow(color: Colors.white,
                                    offset: const Offset(-4.0, -4.0),
                                    blurRadius: 15,
                                    spreadRadius: 1.0,
                                  ),

                                ]

                            ),

                            child: Padding(
                                padding: const EdgeInsets.all(5.0),
                                child: ClipRRect(
                                  borderRadius: BorderRadius.circular(15.0), // Yahan aap apni pasandeeda radius ko set kar sakte hain.
                                  child: Image.asset("assets/images/r7.png"),
                                )
                            ),

                          ),
                          Container(
                            margin: EdgeInsets.only(top: 10),
                            height: height*0.4,
                            width: width*0.45,
                            decoration: BoxDecoration(
                                color: Colors.brown.shade100,
                                borderRadius: BorderRadius.circular(15),
                                boxShadow: [
                                  BoxShadow(color: Colors.brown.shade800,
                                    offset: const Offset(4.0, 4.0),
                                    blurRadius: 15,
                                    spreadRadius: 1.0,
                                  ),
                                  const   BoxShadow(color: Colors.white,
                                    offset: const Offset(-4.0, -4.0),
                                    blurRadius: 15,
                                    spreadRadius: 1.0,
                                  ),

                                ]

                            ),

                            child: Padding(
                                padding: const EdgeInsets.all(5.0),
                                child: ClipRRect(
                                  borderRadius: BorderRadius.circular(15.0), // Yahan aap apni pasandeeda radius ko set kar sakte hain.
                                  child: Image.asset("assets/images/r8.png"),
                                )
                            ),

                          ),
                          Container(
                            margin: EdgeInsets.only(top: 10),
                            height: height*0.3,
                            width: width*0.4,
                            decoration: BoxDecoration(
                                color: Colors.brown.shade100,
                                borderRadius: BorderRadius.circular(15),
                                boxShadow: [
                                  BoxShadow(color: Colors.brown.shade800,
                                    offset: const Offset(4.0, 4.0),
                                    blurRadius: 15,
                                    spreadRadius: 1.0,
                                  ),
                                  const   BoxShadow(color: Colors.white,
                                    offset: const Offset(-4.0, -4.0),
                                    blurRadius: 15,
                                    spreadRadius: 1.0,
                                  ),

                                ]

                            ),

                            child: Padding(
                                padding: const EdgeInsets.all(5.0),
                                child: ClipRRect(
                                  borderRadius: BorderRadius.circular(15.0), // Yahan aap apni pasandeeda radius ko set kar sakte hain.
                                  child: Image.asset("assets/images/r9.png"),
                                )
                            ),

                          ),
                          Container(
                            margin: EdgeInsets.only(top: 10),
                            height: height*0.4,
                            width: width*0.45,
                            decoration: BoxDecoration(
                                color: Colors.brown.shade100,
                                borderRadius: BorderRadius.circular(15),
                                boxShadow: [
                                  BoxShadow(color: Colors.brown.shade800,
                                    offset: const Offset(4.0, 4.0),
                                    blurRadius: 15,
                                    spreadRadius: 1.0,
                                  ),
                                  const   BoxShadow(color: Colors.white,
                                    offset: const Offset(-4.0, -4.0),
                                    blurRadius: 15,
                                    spreadRadius: 1.0,
                                  ),

                                ]

                            ),

                            child: Padding(
                                padding: const EdgeInsets.all(5.0),
                                child: ClipRRect(
                                  borderRadius: BorderRadius.circular(15.0), // Yahan aap apni pasandeeda radius ko set kar sakte hain.
                                  child: Image.asset("assets/images/r10.png"),
                                )
                            ),

                          ),
                          Container(
                            margin: EdgeInsets.only(top: 10),
                            height: height*0.3,
                            width: width*0.4,
                            decoration: BoxDecoration(
                                color: Colors.brown.shade100,
                                borderRadius: BorderRadius.circular(15),
                                boxShadow: [
                                  BoxShadow(color: Colors.brown.shade800,
                                    offset: const Offset(4.0, 4.0),
                                    blurRadius: 15,
                                    spreadRadius: 1.0,
                                  ),
                                  const   BoxShadow(color: Colors.white,
                                    offset: const Offset(-4.0, -4.0),
                                    blurRadius: 15,
                                    spreadRadius: 1.0,
                                  ),

                                ]

                            ),

                            child: Padding(
                                padding: const EdgeInsets.all(5.0),
                                child: ClipRRect(
                                  borderRadius: BorderRadius.circular(15.0), // Yahan aap apni pasandeeda radius ko set kar sakte hain.
                                  child: Image.asset("assets/images/n6.jpeg"),
                                )
                            ),

                          ),
                          Container(
                            margin: EdgeInsets.only(top: 10),
                            height: height*0.4,
                            width: width*0.45,
                            decoration: BoxDecoration(
                                color: Colors.brown.shade100,
                                borderRadius: BorderRadius.circular(15),
                                boxShadow: [
                                  BoxShadow(color: Colors.brown.shade800,
                                    offset: const Offset(4.0, 4.0),
                                    blurRadius: 15,
                                    spreadRadius: 1.0,
                                  ),
                                  const   BoxShadow(color: Colors.white,
                                    offset: const Offset(-4.0, -4.0),
                                    blurRadius: 15,
                                    spreadRadius: 1.0,
                                  ),

                                ]

                            ),

                            child: Padding(
                                padding: const EdgeInsets.all(5.0),
                                child: ClipRRect(
                                  borderRadius: BorderRadius.circular(15.0), // Yahan aap apni pasandeeda radius ko set kar sakte hain.
                                  child: Image.asset("assets/images/n7.jpeg"),
                                )
                            ),

                          ),
                          Container(
                            margin: EdgeInsets.only(top: 10),
                            height: height*0.3,
                            width: width*0.4,
                            decoration: BoxDecoration(
                                color: Colors.brown.shade100,
                                borderRadius: BorderRadius.circular(15),
                                boxShadow: [
                                  BoxShadow(color: Colors.brown.shade800,
                                    offset: const Offset(4.0, 4.0),
                                    blurRadius: 15,
                                    spreadRadius: 1.0,
                                  ),
                                  const   BoxShadow(color: Colors.white,
                                    offset: const Offset(-4.0, -4.0),
                                    blurRadius: 15,
                                    spreadRadius: 1.0,
                                  ),

                                ]

                            ),

                            child: Padding(
                                padding: const EdgeInsets.all(5.0),
                                child: ClipRRect(
                                  borderRadius: BorderRadius.circular(15.0), // Yahan aap apni pasandeeda radius ko set kar sakte hain.
                                  child: Image.asset("assets/images/n8.jpeg"),
                                )
                            ),

                          ),
                          Container(
                            margin: EdgeInsets.only(top: 10),
                            height: height*0.4,
                            width: width*0.45,
                            decoration: BoxDecoration(
                                color: Colors.brown.shade100,
                                borderRadius: BorderRadius.circular(15),
                                boxShadow: [
                                  BoxShadow(color: Colors.brown.shade800,
                                    offset: const Offset(4.0, 4.0),
                                    blurRadius: 15,
                                    spreadRadius: 1.0,
                                  ),
                                  const   BoxShadow(color: Colors.white,
                                    offset: const Offset(-4.0, -4.0),
                                    blurRadius: 15,
                                    spreadRadius: 1.0,
                                  ),

                                ]

                            ),

                            child: Padding(
                                padding: const EdgeInsets.all(5.0),
                                child: ClipRRect(
                                  borderRadius: BorderRadius.circular(15.0), // Yahan aap apni pasandeeda radius ko set kar sakte hain.
                                  child: Image.asset("assets/images/n9.jpeg"),
                                )
                            ),

                          ),
                          Container(
                            margin: EdgeInsets.only(top: 10),
                            height: height*0.3,
                            width: width*0.4,
                            decoration: BoxDecoration(
                                color: Colors.brown.shade100,
                                borderRadius: BorderRadius.circular(15),
                                boxShadow: [
                                  BoxShadow(color: Colors.brown.shade800,
                                    offset: const Offset(4.0, 4.0),
                                    blurRadius: 15,
                                    spreadRadius: 1.0,
                                  ),
                                  const   BoxShadow(color: Colors.white,
                                    offset: const Offset(-4.0, -4.0),
                                    blurRadius: 15,
                                    spreadRadius: 1.0,
                                  ),

                                ]

                            ),

                            child: Padding(
                                padding: const EdgeInsets.all(5.0),
                                child: ClipRRect(
                                  borderRadius: BorderRadius.circular(15.0), // Yahan aap apni pasandeeda radius ko set kar sakte hain.
                                  child: Image.asset("assets/images/n10.jpeg"),
                                )
                            ),

                          ),
                        ],
                      ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Column(
                      children: [
                        Container(
                          margin: EdgeInsets.only(top: 10),
                          height: height*0.3,
                          width: width*0.4,
                          decoration: BoxDecoration(
                              color: Colors.brown.shade100,
                              borderRadius: BorderRadius.circular(15),
                              boxShadow: [
                                BoxShadow(color: Colors.brown.shade800,
                                  offset: const Offset(4.0, 4.0),
                                  blurRadius: 15,
                                  spreadRadius: 1.0,
                                ),
                                const   BoxShadow(color: Colors.white,
                                  offset: const Offset(-4.0, -4.0),
                                  blurRadius: 15,
                                  spreadRadius: 1.0,
                                ),

                              ]

                          ),

                          child: Padding(
                              padding: const EdgeInsets.all(5.0),
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(15.0), // Yahan aap apni pasandeeda radius ko set kar sakte hain.
                                child: Image.asset("assets/images/s5.png"),
                              )
                          ),

                        ),
                        Container(
                          margin: EdgeInsets.only(top: 10),
                          height: height*0.4,
                          width: width*0.45,
                          decoration: BoxDecoration(
                              color: Colors.brown.shade100,
                              borderRadius: BorderRadius.circular(15),
                              boxShadow: [
                                BoxShadow(color: Colors.brown.shade800,
                                  offset: const Offset(4.0, 4.0),
                                  blurRadius: 15,
                                  spreadRadius: 1.0,
                                ),
                                const   BoxShadow(color: Colors.white,
                                  offset: const Offset(-4.0, -4.0),
                                  blurRadius: 15,
                                  spreadRadius: 1.0,
                                ),

                              ]

                          ),

                          child: Padding(
                              padding: const EdgeInsets.all(5.0),
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(15.0), // Yahan aap apni pasandeeda radius ko set kar sakte hain.
                                child: Image.asset("assets/images/s6.png"),
                              )
                          ),

                        ),
                        Container(
                          margin: EdgeInsets.only(top: 10),
                          height: height*0.3,
                          width: width*0.4,
                          decoration: BoxDecoration(
                              color: Colors.brown.shade100,
                              borderRadius: BorderRadius.circular(15),
                              boxShadow: [
                                BoxShadow(color: Colors.brown.shade800,
                                  offset: const Offset(4.0, 4.0),
                                  blurRadius: 15,
                                  spreadRadius: 1.0,
                                ),
                                const   BoxShadow(color: Colors.white,
                                  offset: const Offset(-4.0, -4.0),
                                  blurRadius: 15,
                                  spreadRadius: 1.0,
                                ),

                              ]

                          ),

                          child: Padding(
                              padding: const EdgeInsets.all(5.0),
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(15.0), // Yahan aap apni pasandeeda radius ko set kar sakte hain.
                                child: Image.asset("assets/images/s7.png"),
                              )
                          ),

                        ),
                        Container(
                          margin: EdgeInsets.only(top: 10),
                          height: height*0.4,
                          width: width*0.45,
                          decoration: BoxDecoration(
                              color: Colors.brown.shade100,
                              borderRadius: BorderRadius.circular(15),
                              boxShadow: [
                                BoxShadow(color: Colors.brown.shade800,
                                  offset: const Offset(4.0, 4.0),
                                  blurRadius: 15,
                                  spreadRadius: 1.0,
                                ),
                                const   BoxShadow(color: Colors.white,
                                  offset: const Offset(-4.0, -4.0),
                                  blurRadius: 15,
                                  spreadRadius: 1.0,
                                ),

                              ]

                          ),

                          child: Padding(
                              padding: const EdgeInsets.all(5.0),
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(15.0), // Yahan aap apni pasandeeda radius ko set kar sakte hain.
                                child: Image.asset("assets/images/s8.png"),
                              )
                          ),

                        ),
                        Container(
                          margin: EdgeInsets.only(top: 10),
                          height: height*0.3,
                          width: width*0.4,
                          decoration: BoxDecoration(
                              color: Colors.brown.shade100,
                              borderRadius: BorderRadius.circular(15),
                              boxShadow: [
                                BoxShadow(color: Colors.brown.shade800,
                                  offset: const Offset(4.0, 4.0),
                                  blurRadius: 15,
                                  spreadRadius: 1.0,
                                ),
                                const   BoxShadow(color: Colors.white,
                                  offset: const Offset(-4.0, -4.0),
                                  blurRadius: 15,
                                  spreadRadius: 1.0,
                                ),

                              ]

                          ),

                          child: Padding(
                              padding: const EdgeInsets.all(5.0),
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(15.0), // Yahan aap apni pasandeeda radius ko set kar sakte hain.
                                child: Image.asset("assets/images/s9.png"),
                              )
                          ),

                        ),
                        Container(
                          margin: EdgeInsets.only(top: 10),
                          height: height*0.4,
                          width: width*0.45,
                          decoration: BoxDecoration(
                              color: Colors.brown.shade100,
                              borderRadius: BorderRadius.circular(15),
                              boxShadow: [
                                BoxShadow(color: Colors.brown.shade800,
                                  offset: const Offset(4.0, 4.0),
                                  blurRadius: 15,
                                  spreadRadius: 1.0,
                                ),
                                const   BoxShadow(color: Colors.white,
                                  offset: const Offset(-4.0, -4.0),
                                  blurRadius: 15,
                                  spreadRadius: 1.0,
                                ),

                              ]

                          ),

                          child: Padding(
                              padding: const EdgeInsets.all(5.0),
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(15.0), // Yahan aap apni pasandeeda radius ko set kar sakte hain.
                                child: Image.asset("assets/images/p4.png"),
                              )
                          ),

                        ),
                        Container(
                          margin: EdgeInsets.only(top: 10),
                          height: height*0.3,
                          width: width*0.4,
                          decoration: BoxDecoration(
                              color: Colors.brown.shade100,
                              borderRadius: BorderRadius.circular(15),
                              boxShadow: [
                                BoxShadow(color: Colors.brown.shade800,
                                  offset: const Offset(4.0, 4.0),
                                  blurRadius: 15,
                                  spreadRadius: 1.0,
                                ),
                                const   BoxShadow(color: Colors.white,
                                  offset: const Offset(-4.0, -4.0),
                                  blurRadius: 15,
                                  spreadRadius: 1.0,
                                ),

                              ]

                          ),

                          child: Padding(
                              padding: const EdgeInsets.all(5.0),
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(15.0), // Yahan aap apni pasandeeda radius ko set kar sakte hain.
                                child: Image.asset("assets/images/p5.png"),
                              )
                          ),

                        ),
                        Container(
                          margin: EdgeInsets.only(top: 10),
                          height: height*0.4,
                          width: width*0.45,
                          decoration: BoxDecoration(
                              color: Colors.brown.shade100,
                              borderRadius: BorderRadius.circular(15),
                              boxShadow: [
                                BoxShadow(color: Colors.brown.shade800,
                                  offset: const Offset(4.0, 4.0),
                                  blurRadius: 15,
                                  spreadRadius: 1.0,
                                ),
                                const   BoxShadow(color: Colors.white,
                                  offset: const Offset(-4.0, -4.0),
                                  blurRadius: 15,
                                  spreadRadius: 1.0,
                                ),

                              ]

                          ),

                          child: Padding(
                              padding: const EdgeInsets.all(5.0),
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(15.0), // Yahan aap apni pasandeeda radius ko set kar sakte hain.
                                child: Image.asset("assets/images/p6.png"),
                              )
                          ),

                        ),
                        Container(
                          margin: EdgeInsets.only(top: 10),
                          height: height*0.3,
                          width: width*0.4,
                          decoration: BoxDecoration(
                              color: Colors.brown.shade100,
                              borderRadius: BorderRadius.circular(15),
                              boxShadow: [
                                BoxShadow(color: Colors.brown.shade800,
                                  offset: const Offset(4.0, 4.0),
                                  blurRadius: 15,
                                  spreadRadius: 1.0,
                                ),
                                const   BoxShadow(color: Colors.white,
                                  offset: const Offset(-4.0, -4.0),
                                  blurRadius: 15,
                                  spreadRadius: 1.0,
                                ),

                              ]

                          ),

                          child: Padding(
                              padding: const EdgeInsets.all(5.0),
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(15.0), // Yahan aap apni pasandeeda radius ko set kar sakte hain.
                                child: Image.asset("assets/images/p7.png"),
                              )
                          ),

                        ),
                        Container(
                          margin: EdgeInsets.only(top: 10),
                          height: height*0.4,
                          width: width*0.45,
                          decoration: BoxDecoration(
                              color: Colors.brown.shade100,
                              borderRadius: BorderRadius.circular(15),
                              boxShadow: [
                                BoxShadow(color: Colors.brown.shade800,
                                  offset: const Offset(4.0, 4.0),
                                  blurRadius: 15,
                                  spreadRadius: 1.0,
                                ),
                                const   BoxShadow(color: Colors.white,
                                  offset: const Offset(-4.0, -4.0),
                                  blurRadius: 15,
                                  spreadRadius: 1.0,
                                ),

                              ]

                          ),

                          child: Padding(
                              padding: const EdgeInsets.all(5.0),
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(15.0), // Yahan aap apni pasandeeda radius ko set kar sakte hain.
                                child: Image.asset("assets/images/p8.png"),
                              )
                          ),

                        ),
                        Container(
                          margin: EdgeInsets.only(top: 10),
                          height: height*0.3,
                          width: width*0.4,
                          decoration: BoxDecoration(
                              color: Colors.brown.shade100,
                              borderRadius: BorderRadius.circular(15),
                              boxShadow: [
                                BoxShadow(color: Colors.brown.shade800,
                                  offset: const Offset(4.0, 4.0),
                                  blurRadius: 15,
                                  spreadRadius: 1.0,
                                ),
                                const   BoxShadow(color: Colors.white,
                                  offset: const Offset(-4.0, -4.0),
                                  blurRadius: 15,
                                  spreadRadius: 1.0,
                                ),

                              ]

                          ),

                          child: Padding(
                              padding: const EdgeInsets.all(5.0),
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(15.0), // Yahan aap apni pasandeeda radius ko set kar sakte hain.
                                child: Image.asset("assets/images/p9.png"),
                              )
                          ),

                        ),
                        Container(
                          margin: EdgeInsets.only(top: 10),
                          height: height*0.4,
                          width: width*0.45,
                          decoration: BoxDecoration(
                              color: Colors.brown.shade100,
                              borderRadius: BorderRadius.circular(15),
                              boxShadow: [
                                BoxShadow(color: Colors.brown.shade800,
                                  offset: const Offset(4.0, 4.0),
                                  blurRadius: 15,
                                  spreadRadius: 1.0,
                                ),
                                const   BoxShadow(color: Colors.white,
                                  offset: const Offset(-4.0, -4.0),
                                  blurRadius: 15,
                                  spreadRadius: 1.0,
                                ),

                              ]

                          ),

                          child: Padding(
                              padding: const EdgeInsets.all(5.0),
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(15.0), // Yahan aap apni pasandeeda radius ko set kar sakte hain.
                                child: Image.asset("assets/images/p10.png"),
                              )
                          ),

                        ),
                        Container(
                          margin: EdgeInsets.only(top: 10),
                          height: height*0.3,
                          width: width*0.4,
                          decoration: BoxDecoration(
                              color: Colors.brown.shade100,
                              borderRadius: BorderRadius.circular(15),
                              boxShadow: [
                                BoxShadow(color: Colors.brown.shade800,
                                  offset: const Offset(4.0, 4.0),
                                  blurRadius: 15,
                                  spreadRadius: 1.0,
                                ),
                                const   BoxShadow(color: Colors.white,
                                  offset: const Offset(-4.0, -4.0),
                                  blurRadius: 15,
                                  spreadRadius: 1.0,
                                ),

                              ]

                          ),

                          child: Padding(
                              padding: const EdgeInsets.all(5.0),
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(15.0), // Yahan aap apni pasandeeda radius ko set kar sakte hain.
                                child: Image.asset("assets/images/p11.png"),
                              )
                          ),

                        ),
                        Container(
                          margin: EdgeInsets.only(top: 10),
                          height: height*0.4,
                          width: width*0.45,
                          decoration: BoxDecoration(
                              color: Colors.brown.shade100,
                              borderRadius: BorderRadius.circular(15),
                              boxShadow: [
                                BoxShadow(color: Colors.brown.shade800,
                                  offset: const Offset(4.0, 4.0),
                                  blurRadius: 15,
                                  spreadRadius: 1.0,
                                ),
                                const   BoxShadow(color: Colors.white,
                                  offset: const Offset(-4.0, -4.0),
                                  blurRadius: 15,
                                  spreadRadius: 1.0,
                                ),

                              ]

                          ),

                          child: Padding(
                              padding: const EdgeInsets.all(5.0),
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(15.0), // Yahan aap apni pasandeeda radius ko set kar sakte hain.
                                child: Image.asset("assets/images/8a.png"),
                              )
                          ),

                        ),
                        Container(
                          margin: EdgeInsets.only(top: 10),
                          height: height*0.3,
                          width: width*0.4,
                          decoration: BoxDecoration(
                              color: Colors.brown.shade100,
                              borderRadius: BorderRadius.circular(15),
                              boxShadow: [
                                BoxShadow(color: Colors.brown.shade800,
                                  offset: const Offset(4.0, 4.0),
                                  blurRadius: 15,
                                  spreadRadius: 1.0,
                                ),
                                const   BoxShadow(color: Colors.white,
                                  offset: const Offset(-4.0, -4.0),
                                  blurRadius: 15,
                                  spreadRadius: 1.0,
                                ),

                              ]

                          ),

                          child: Padding(
                              padding: const EdgeInsets.all(5.0),
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(15.0), // Yahan aap apni pasandeeda radius ko set kar sakte hain.
                                child: Image.asset("assets/images/9a.png"),
                              )
                          ),

                        ),
                        Container(
                          margin: EdgeInsets.only(top: 10),
                          height: height*0.4,
                          width: width*0.45,
                          decoration: BoxDecoration(
                              color: Colors.brown.shade100,
                              borderRadius: BorderRadius.circular(15),
                              boxShadow: [
                                BoxShadow(color: Colors.brown.shade800,
                                  offset: const Offset(4.0, 4.0),
                                  blurRadius: 15,
                                  spreadRadius: 1.0,
                                ),
                                const   BoxShadow(color: Colors.white,
                                  offset: const Offset(-4.0, -4.0),
                                  blurRadius: 15,
                                  spreadRadius: 1.0,
                                ),

                              ]

                          ),

                          child: Padding(
                              padding: const EdgeInsets.all(5.0),
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(15.0), // Yahan aap apni pasandeeda radius ko set kar sakte hain.
                                child: Image.asset("assets/images/10a.png"),
                              )
                          ),

                        ),
                        Container(
                          margin: EdgeInsets.only(top: 10),
                          height: height*0.3,
                          width: width*0.4,
                          decoration: BoxDecoration(
                              color: Colors.brown.shade100,
                              borderRadius: BorderRadius.circular(15),
                              boxShadow: [
                                BoxShadow(color: Colors.brown.shade800,
                                  offset: const Offset(4.0, 4.0),
                                  blurRadius: 15,
                                  spreadRadius: 1.0,
                                ),
                                const   BoxShadow(color: Colors.white,
                                  offset: const Offset(-4.0, -4.0),
                                  blurRadius: 15,
                                  spreadRadius: 1.0,
                                ),

                              ]

                          ),

                          child: Padding(
                              padding: const EdgeInsets.all(5.0),
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(15.0), // Yahan aap apni pasandeeda radius ko set kar sakte hain.
                                child: Image.asset("assets/images/r1.png"),
                              )
                          ),

                        ),
                        Container(
                          margin: EdgeInsets.only(top: 10),
                          height: height*0.4,
                          width: width*0.45,
                          decoration: BoxDecoration(
                              color: Colors.brown.shade100,
                              borderRadius: BorderRadius.circular(15),
                              boxShadow: [
                                BoxShadow(color: Colors.brown.shade800,
                                  offset: const Offset(4.0, 4.0),
                                  blurRadius: 15,
                                  spreadRadius: 1.0,
                                ),
                                const   BoxShadow(color: Colors.white,
                                  offset: const Offset(-4.0, -4.0),
                                  blurRadius: 15,
                                  spreadRadius: 1.0,
                                ),

                              ]

                          ),

                          child: Padding(
                              padding: const EdgeInsets.all(5.0),
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(15.0), // Yahan aap apni pasandeeda radius ko set kar sakte hain.
                                child: Image.asset("assets/images/r2.png"),
                              )
                          ),

                        ),
                        Container(
                          margin: EdgeInsets.only(top: 10),
                          height: height*0.3,
                          width: width*0.4,
                          decoration: BoxDecoration(
                              color: Colors.brown.shade100,
                              borderRadius: BorderRadius.circular(15),
                              boxShadow: [
                                BoxShadow(color: Colors.brown.shade800,
                                  offset: const Offset(4.0, 4.0),
                                  blurRadius: 15,
                                  spreadRadius: 1.0,
                                ),
                                const   BoxShadow(color: Colors.white,
                                  offset: const Offset(-4.0, -4.0),
                                  blurRadius: 15,
                                  spreadRadius: 1.0,
                                ),

                              ]

                          ),

                          child: Padding(
                              padding: const EdgeInsets.all(5.0),
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(15.0), // Yahan aap apni pasandeeda radius ko set kar sakte hain.
                                child: Image.asset("assets/images/r3.png"),
                              )
                          ),

                        ),
                        Container(
                          margin: EdgeInsets.only(top: 10),
                          height: height*0.4,
                          width: width*0.45,
                          decoration: BoxDecoration(
                              color: Colors.brown.shade100,
                              borderRadius: BorderRadius.circular(15),
                              boxShadow: [
                                BoxShadow(color: Colors.brown.shade800,
                                  offset: const Offset(4.0, 4.0),
                                  blurRadius: 15,
                                  spreadRadius: 1.0,
                                ),
                                const   BoxShadow(color: Colors.white,
                                  offset: const Offset(-4.0, -4.0),
                                  blurRadius: 15,
                                  spreadRadius: 1.0,
                                ),

                              ]

                          ),

                          child: Padding(
                              padding: const EdgeInsets.all(5.0),
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(15.0), // Yahan aap apni pasandeeda radius ko set kar sakte hain.
                                child: Image.asset("assets/images/r4.png"),
                              )
                          ),

                        ),
                        Container(
                          margin: EdgeInsets.only(top: 10),
                          height: height*0.3,
                          width: width*0.4,
                          decoration: BoxDecoration(
                              color: Colors.brown.shade100,
                              borderRadius: BorderRadius.circular(15),
                              boxShadow: [
                                BoxShadow(color: Colors.brown.shade800,
                                  offset: const Offset(4.0, 4.0),
                                  blurRadius: 15,
                                  spreadRadius: 1.0,
                                ),
                                const   BoxShadow(color: Colors.white,
                                  offset: const Offset(-4.0, -4.0),
                                  blurRadius: 15,
                                  spreadRadius: 1.0,
                                ),

                              ]

                          ),

                          child: Padding(
                              padding: const EdgeInsets.all(5.0),
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(15.0), // Yahan aap apni pasandeeda radius ko set kar sakte hain.
                                child: Image.asset("assets/images/r5.png"),
                              )
                          ),

                        ),
                        Container(
                          margin: EdgeInsets.only(top: 10),
                          height: height*0.4,
                          width: width*0.45,
                          decoration: BoxDecoration(
                              color: Colors.brown.shade100,
                              borderRadius: BorderRadius.circular(15),
                              boxShadow: [
                                BoxShadow(color: Colors.brown.shade800,
                                  offset: const Offset(4.0, 4.0),
                                  blurRadius: 15,
                                  spreadRadius: 1.0,
                                ),
                                const   BoxShadow(color: Colors.white,
                                  offset: const Offset(-4.0, -4.0),
                                  blurRadius: 15,
                                  spreadRadius: 1.0,
                                ),

                              ]

                          ),

                          child: Padding(
                              padding: const EdgeInsets.all(5.0),
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(15.0), // Yahan aap apni pasandeeda radius ko set kar sakte hain.
                                child: Image.asset("assets/images/n1.jpeg"),
                              )
                          ),

                        ),
                        Container(
                          margin: EdgeInsets.only(top: 10),
                          height: height*0.3,
                          width: width*0.4,
                          decoration: BoxDecoration(
                              color: Colors.brown.shade100,
                              borderRadius: BorderRadius.circular(15),
                              boxShadow: [
                                BoxShadow(color: Colors.brown.shade800,
                                  offset: const Offset(4.0, 4.0),
                                  blurRadius: 15,
                                  spreadRadius: 1.0,
                                ),
                                const   BoxShadow(color: Colors.white,
                                  offset: const Offset(-4.0, -4.0),
                                  blurRadius: 15,
                                  spreadRadius: 1.0,
                                ),

                              ]

                          ),

                          child: Padding(
                              padding: const EdgeInsets.all(5.0),
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(15.0), // Yahan aap apni pasandeeda radius ko set kar sakte hain.
                                child: Image.asset("assets/images/n2.jpeg"),
                              )
                          ),

                        ),
                        Container(
                          margin: EdgeInsets.only(top: 10),
                          height: height*0.4,
                          width: width*0.45,
                          decoration: BoxDecoration(
                              color: Colors.brown.shade100,
                              borderRadius: BorderRadius.circular(15),
                              boxShadow: [
                                BoxShadow(color: Colors.brown.shade800,
                                  offset: const Offset(4.0, 4.0),
                                  blurRadius: 15,
                                  spreadRadius: 1.0,
                                ),
                                const   BoxShadow(color: Colors.white,
                                  offset: const Offset(-4.0, -4.0),
                                  blurRadius: 15,
                                  spreadRadius: 1.0,
                                ),

                              ]

                          ),

                          child: Padding(
                              padding: const EdgeInsets.all(5.0),
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(15.0), // Yahan aap apni pasandeeda radius ko set kar sakte hain.
                                child: Image.asset("assets/images/n3.jpeg"),
                              )
                          ),

                        ),
                        Container(
                          margin: EdgeInsets.only(top: 10),
                          height: height*0.3,
                          width: width*0.4,
                          decoration: BoxDecoration(
                              color: Colors.brown.shade100,
                              borderRadius: BorderRadius.circular(15),
                              boxShadow: [
                                BoxShadow(color: Colors.brown.shade800,
                                  offset: const Offset(4.0, 4.0),
                                  blurRadius: 15,
                                  spreadRadius: 1.0,
                                ),
                                const   BoxShadow(color: Colors.white,
                                  offset: const Offset(-4.0, -4.0),
                                  blurRadius: 15,
                                  spreadRadius: 1.0,
                                ),

                              ]

                          ),

                          child: Padding(
                              padding: const EdgeInsets.all(5.0),
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(15.0), // Yahan aap apni pasandeeda radius ko set kar sakte hain.
                                child: Image.asset("assets/images/n4.jpeg"),
                              )
                          ),

                        ),
                        Container(
                          margin: EdgeInsets.only(top: 10),
                          height: height*0.4,
                          width: width*0.45,
                          decoration: BoxDecoration(
                              color: Colors.brown.shade100,
                              borderRadius: BorderRadius.circular(15),
                              boxShadow: [
                                BoxShadow(color: Colors.brown.shade800,
                                  offset: const Offset(4.0, 4.0),
                                  blurRadius: 15,
                                  spreadRadius: 1.0,
                                ),
                                const   BoxShadow(color: Colors.white,
                                  offset: const Offset(-4.0, -4.0),
                                  blurRadius: 15,
                                  spreadRadius: 1.0,
                                ),

                              ]

                          ),

                          child: Padding(
                              padding: const EdgeInsets.all(5.0),
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(15.0), // Yahan aap apni pasandeeda radius ko set kar sakte hain.
                                child: Image.asset("assets/images/n5.jpeg"),
                              )
                          ),

                        ),

                      ],
                    ),
                  ),
                ]
              ),
            ),
          ),
        ),
      )

    );
  }
}
