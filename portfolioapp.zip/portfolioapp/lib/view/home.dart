import 'package:flutter/material.dart';
import 'package:portfolioapp/view/portfolio.dart';
import 'package:portfolioapp/view/portfolioscroll.dart';
import 'package:portfolioapp/view/resume.dart';
class home extends StatelessWidget {
  const home({super.key});

  @override
  Widget build(BuildContext context) {
    final height=MediaQuery.of(context).size.height*1;
    final width=MediaQuery.of(context).size.width*1;
    return Scaffold(
      appBar: AppBar(
      title: Text("Home",style: TextStyle(color: Colors.brown.shade900,fontWeight: FontWeight.w900),),
      centerTitle: true,
      backgroundColor: Colors.brown.shade100,

      /*actions: [
          Padding(
            padding: const EdgeInsets.only(right: 30.0),
            child: Container(
              width: 30,
              child: Image.asset(
                'assets/images/pic.png',
              ),
            ),
          ),
        ],*/
    ),
      body:

          Container( decoration: BoxDecoration(color: Colors.brown.shade100,
             image: DecorationImage(
              image: AssetImage('assets/images/hts.jpeg'),fit: BoxFit.fitWidth),
          ),
            child:  Padding(
              padding: const EdgeInsets.all(20.0),
              child: Container(
                width: double.infinity,
                height: double.infinity,
                decoration: BoxDecoration(color: Colors.white30),
                child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Container(
                    width: double.infinity,
                    height: double.infinity,
                    decoration: BoxDecoration(color: Colors.brown.shade100),
                    child:    Column(
                      children: [
                        Padding(
                          padding: const EdgeInsets.only(top: 50,left:30,right: 30),
                          child: Text("Unlock your Potential; Reveal your Story.",style:
                          TextStyle(color: Colors.brown.shade900,fontWeight: FontWeight.bold,fontSize: 25),),
                        ),
                        SingleChildScrollView(
                          scrollDirection: Axis.vertical,
                          child: Container(
                           // margin: EdgeInsets.only(top: 30,),
                            width: 300,
                          //  height: 400,
                           /* decoration: BoxDecoration(color: Colors.brown.shade100,
                               *//* image: DecorationImage(
                                    image: AssetImage('assets/images/t2.jpeg'),fit: BoxFit.fitWidth)*//*

                            ),*/
                            child: SingleChildScrollView(
                              scrollDirection: Axis.vertical,
                              child: Column(

                                children: [
                                  InkWell(
                                    onTap:(){
                                      Navigator.push(context, MaterialPageRoute(builder: (context) => portfolioscroll()));
                                    },
                                    child: Container(
                                      width: 300,
                                      height: 200,
                                      margin: EdgeInsets.only(top: 80,left: 10,right: 10),
                                      decoration: BoxDecoration(color: Colors.white60,borderRadius: BorderRadius.circular(10),
                                          image: DecorationImage(
                                              image: AssetImage('assets/images/t1.jpeg'),fit: BoxFit.fitWidth)
                                      ),
                                      child:Column(
                                        children: [
                                            Container(margin: EdgeInsets.only(top: 30,),
                                                child: Text("Portfolio Showcase",style:TextStyle(fontSize: 21,color: Colors.white,fontWeight: FontWeight.w900),)),

                                          //Image.asset('assets/images/circleimg.png'),
                                          Icon(Icons.browse_gallery,color: Colors.white,size: 60)
                                        ],
                                      ),

                                    ),
                                  ),

                                  InkWell(
                                    onTap:(){
                                      Navigator.push(context, MaterialPageRoute(builder: (context) => resume()));
                                    },
                                    child: Container(
                                      width: 300,
                                      height: 200,
                                      margin: EdgeInsets.only(top: 20,left: 10,right: 10),
                                      decoration: BoxDecoration(color: Colors.white60,borderRadius: BorderRadius.circular(10),
                                          image: DecorationImage(
                                              image: AssetImage('assets/images/t3.jpeg'),fit: BoxFit.fitWidth)

                                      ),
                                      child:Column(
                                        children: [

                                          Container(margin: EdgeInsets.only(top: 30,),
                                                child: Text("Resume",style:TextStyle(fontSize: 21,color: Colors.white,fontWeight: FontWeight.w900),)),

                                          //Image.asset('assets/images/circleimg.png'),
                                          Icon(Icons.account_box,color: Colors.white,size: 60)
                                        ],
                                      ),

                                    ),
                                  ),
                                /*  InkWell(
                                    onTap:(){
                                      Navigator.push(context, MaterialPageRoute(builder: (context) => portfolio()));
                                    },
                                    child: Container(
                                      width: 300,
                                      height: 150,
                                      margin: EdgeInsets.only(top: 20,left: 10,right: 10),
                                      decoration: BoxDecoration(color: Colors.white60,borderRadius: BorderRadius.circular(10),
                                          image: DecorationImage(
                                              image: AssetImage('assets/images/t2.jpeg'),fit: BoxFit.fitWidth)

                                      ),
                                      child:Column(
                                        children: [

                                          Container(margin: EdgeInsets.only(top: 30,),
                                              child: Text("Contact Me ",style:TextStyle(fontSize: 21,color: Colors.white,fontWeight: FontWeight.w900),)),

                                          //Image.asset('assets/images/circleimg.png'),
                                          Icon(Icons.mail_sharp,color: Colors.white,size: 60)
                                        ],
                                      ),

                                    ),
                                  ),*/
                                ],
                              ),
                            ),
                          ),
                        ),
                      /*  Padding(
                          padding: const EdgeInsets.only(top: 30 ),
                          child: ElevatedButton(
                            onPressed: () {
                              // Add your onPressed functionality here
                              print('ElevatedButton pressed');
                            },  style: ElevatedButton.styleFrom(
                            primary: Colors.brown.shade900, // Set the background color here
                          ),
                            child: Text('Contact  me',style: TextStyle(color: Colors.white),),
                          ),
                        ),*/

                      ],
                    ),
                  ),
                ),
              ),
            ) ,
          ),

    );
  }
}
/*
Container( decoration: BoxDecoration(color: Colors.brown.shade100,
*/
/* image: DecorationImage(
              image: AssetImage('assets/images/nine.jpeg'),fit: BoxFit.fitWidth)*//*


),
child:  Padding(
padding: const EdgeInsets.all(20.0),
child: Container(
width: double.infinity,
height: double.infinity,
decoration: BoxDecoration(color: Colors.white30),
child: Padding(
padding: const EdgeInsets.all(8.0),
child: Container(
width: double.infinity,
height: double.infinity,
decoration: BoxDecoration(color: Colors.white30),
child:    Column(
children: [
Container(
margin: EdgeInsets.only(top: 30,left: 10,right: 10),
child: Text("Unlock your potential; reveal your story.",style:TextStyle(fontSize: 21,color: Colors.brown.shade900,fontWeight: FontWeight.w900),)),
Container(
margin: EdgeInsets.only(top: 30,),
width: 300,
height: 400,
decoration: BoxDecoration(color: Colors.brown.shade100,
image: DecorationImage(
image: AssetImage('assets/images/t2.jpeg'),fit: BoxFit.fitWidth)

),
child: Column(

children: [
Container(
width: 300,
height: 150,
margin: EdgeInsets.only(top: 30,left: 10,right: 10),
decoration: BoxDecoration(color: Colors.white60,
),
child:Column(
children: [

InkWell(
onTap:(){
Navigator.push(context, MaterialPageRoute(builder: (context) => portfolio()));
},
child: Container(margin: EdgeInsets.only(top: 30,),
child: Text("Portfolio Showcase",style:TextStyle(fontSize: 21,color: Colors.white,fontWeight: FontWeight.w900),)),
),
//Image.asset('assets/images/circleimg.png'),
Icon(Icons.browse_gallery,color: Colors.white,size: 60)
],
),

),
*/
/*SizedBox(height: 20,),*//*

Container(
width: 300,
height: 150,
margin: EdgeInsets.only(top: 30,left: 10,right: 10),
decoration: BoxDecoration(color: Colors.white60),
child:Column(
children: [

InkWell(
onTap:(){
Navigator.push(context, MaterialPageRoute(builder: (context) => portfolio()));
},
child: Container(margin: EdgeInsets.only(top: 30,),
child: Text("Resume",style:TextStyle(fontSize: 21,color: Colors.white,fontWeight: FontWeight.w900),)),
),
//Image.asset('assets/images/circleimg.png'),
Icon(Icons.account_box,color: Colors.white,size: 60)
],
),

),
],
),
),
Padding(
padding: const EdgeInsets.only(top: 30 ),
child: ElevatedButton(
onPressed: () {
// Add your onPressed functionality here
print('ElevatedButton pressed');
},  style: ElevatedButton.styleFrom(
primary: Colors.brown.shade900, // Set the background color here
),
child: Text('Contact  me',style: TextStyle(color: Colors.white),),
),
),

],
),
),
),
),
) ,
),*/
