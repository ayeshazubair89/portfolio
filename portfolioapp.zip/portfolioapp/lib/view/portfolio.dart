import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';

class portfolio extends StatefulWidget {
  const portfolio({super.key});

  @override
  State<portfolio> createState() => _portfolioState();
}

class _portfolioState extends State<portfolio> {


  @override
  Widget build(BuildContext context) {
    final height=MediaQuery.of(context).size.height*1;
    final width=MediaQuery.of(context).size.width*1;
    return Scaffold(
      appBar: AppBar(
        title: Text("Log Meal",style: TextStyle(color: Colors.white,fontSize: 18,fontWeight: FontWeight.w900),),
        centerTitle: true,
        backgroundColor: Colors.black87,
        leading: IconButton(
          icon: Icon(Icons.arrow_back,color: Colors.white,), // Icon jo aap set karna chahte hain
          onPressed: () {
            // onPressed me aap jo bhi functionality chahte hain wo add kar sakte hain
          },
        ),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 30.0),
            child: Container(
              width: 30,
              child:  IconButton(
                icon: IconButton(
                  icon: Icon(Icons.add, color: Colors.cyan
                      , size: 30),
                  onPressed: () {
                               },
                ),
                onPressed: () {

                },
              ),
            ),
          ),
        ],
      ),
      body:SingleChildScrollView(
        scrollDirection: Axis.vertical,
        child: Container(
          decoration: BoxDecoration(color: Colors.black),
          child: SingleChildScrollView(
            scrollDirection: Axis.vertical,
            child: Column(
              children: [
                Padding(
                  padding: const EdgeInsets.all(10.0),
                  child: Container(
                    width: 500,
                    height: 180,
                    decoration: BoxDecoration(borderRadius: BorderRadius.circular(10),color: Colors.white30),
                    child: Column(
                      children: [
                        Padding(
                          padding: const EdgeInsets.only(top: 10,right: 150,left: 150,),
                          child: Text("Search Your ",style:TextStyle(fontSize: 21,color: Colors.white,fontWeight: FontWeight.bold)),
                        ),
                        Padding(
                          padding: const EdgeInsets.only(right: 150,left: 150,bottom: 10),
                          child: Text("Favourite Meal",style:TextStyle(fontSize: 21,color: Colors.white,fontWeight: FontWeight.bold)),
                        ),
                        Container(

                          child: Padding(
                            padding: const EdgeInsets.only(left: 30,right: 30,top: 10,bottom: 10),
                            child: TextField(
                                cursorColor: Colors.purpleAccent,
                                decoration: InputDecoration(
                                    prefixIcon: Icon(Icons.search,color:Colors.white30),

                                    hintText: 'Search here',
                  hintStyle: TextStyle(color: Colors.white),
                                  suffixIcon: Padding(
                                    padding: const EdgeInsets.only(right: 30),
                                    child: Icon(Icons.drag_handle,color:Colors.cyan,),
                                  ),
                                    contentPadding: EdgeInsets.all(10),
                                    border: OutlineInputBorder(),fillColor: Colors.green,
                                )
                            ),
                          ),
                        ),

                      ],
                    ),
                  ),
                ),
                Container(
                  width: 550,
                  height: 250,
                  margin: EdgeInsets.only(top: 10,left: 10,right: 10),
                  decoration: BoxDecoration(borderRadius: BorderRadius.circular(10),
            color: Colors.white30,
                  ),
                  child:
                Column(
                  children: [
                    Column(
                      children: [
                        Center(
                          child: Row(
                            children: [
                              Container(
                                  width: 150,
                                  height: 150,
                                  margin: EdgeInsets.only(left: 10,right: 10),
                                  decoration: BoxDecoration(borderRadius: BorderRadius.circular(10),

                                  ),
                                  child:
                                  Image.asset("assets/images/img.png",height: 50,width: 50,),),
                              Center(
                                child: Container(
                                  width: 250,
                                  height: 210,
                                  child:
                                Column(
                                  children: [
                                    Padding(
                                      padding: const EdgeInsets.only(top:58,),
                                      child: Container(
                                        child: Row(children: [
                                          Text("Vegetables",style:TextStyle(fontSize: 20,color: Colors.white,fontWeight: FontWeight.w900),),
                                          Text("  120g",style:TextStyle(color: Colors.black45,fontWeight: FontWeight.w400),),
                                          Icon(Icons.battery_charging_full_sharp,color: Colors.red,),
                                          Text("  328 Kcal",style:TextStyle(fontSize: 16,color: Colors.orangeAccent,fontWeight: FontWeight.w400),),

                                        ],),),
                                    ),
                                    SizedBox(height: 20,),
                                    Center(
                                      child: Padding(
                                        padding: const EdgeInsets.only(left: 20,),
                                        child: Container(child: Row(
                                          children: [
                                            Column(children: [
                                              Text("Protien",style:TextStyle(fontSize: 16,color: Colors.black45)),
                                              Text("530",style:TextStyle(fontSize: 20,color: Colors.white,fontWeight: FontWeight.bold)),
                                            ],),
                                            SizedBox(width: 10,),
                                            Container(
                                              width: 2,height: 35,decoration: BoxDecoration(color: Colors.white,),
                                            ),
                                            SizedBox(width: 10,),
                                            Column(children: [
                                              Text("Fats",style:TextStyle(fontSize: 16,color: Colors.black45)),
                                              Text("103",style:TextStyle(fontSize: 20,color: Colors.white,fontWeight: FontWeight.bold)),
                                            ],),
                                            SizedBox(width: 10,),
                                            Container(
                                              width: 2,height: 35,decoration: BoxDecoration(color: Colors.white,),
                                            ),
                                            SizedBox(width: 10,),
                                            Column(children: [
                                              Text("Carbs",style:TextStyle(fontSize: 16,color: Colors.black45)),
                                              Text("250",style:TextStyle(fontSize: 20,color: Colors.white,fontWeight: FontWeight.bold)),
                                            ],),
                                          ],
                                        ),),
                                      ),
                                    ),
                                  ],
                                )
                                  ,),
                              ),
                            ],
                          ),
                        ),


                      ],
                    ),
                    Padding(
                      padding: const EdgeInsets.only(left:80),
                      child: Container(
                        width: 250,
                        height: 35,

                        child: ElevatedButton(onPressed:(){

                        }, child: Text('Add to Dairy',style:TextStyle(color: Colors.black,fontSize: 16,fontWeight: FontWeight.bold, ) ,),
                          style: ElevatedButton.styleFrom(foregroundColor: Colors.black45,primary: Colors.white,shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10), // Button ke corners ka radius
                          ),),
                        ),
                      ),
                    )
                  ],
                ),
                ),
                Container(
                  width: 550,
                  height: 250,
                  margin: EdgeInsets.only(top: 10,left: 10,right: 10),
                  decoration: BoxDecoration(borderRadius: BorderRadius.circular(10),
                    color: Colors.white30,
                  ),
                  child:
                  Column(
                    children: [
                      Column(
                        children: [
                          Center(
                            child: Row(
                              children: [
                                Container(
                                  width: 150,
                                  height: 150,
                                  margin: EdgeInsets.only(left: 10,right: 10),
                                  decoration: BoxDecoration(borderRadius: BorderRadius.circular(10),

                                  ),
                                  child:
                                  Image.asset("assets/images/img.png",height: 50,width: 50,),),
                                Center(
                                  child: Container(
                                    width: 250,
                                    height: 210,
                                    child:
                                    Column(
                                      children: [
                                        Padding(
                                          padding: const EdgeInsets.only(top:58,),
                                          child: Container(
                                            child: Row(children: [
                                              Text("Vegetables",style:TextStyle(fontSize: 20,color: Colors.white,fontWeight: FontWeight.w900),),
                                              Text("  120g",style:TextStyle(color: Colors.black45,fontWeight: FontWeight.w400),),
                                              Icon(Icons.battery_charging_full_sharp,color: Colors.red,),
                                              Text("  328 Kcal",style:TextStyle(fontSize: 16,color: Colors.orangeAccent,fontWeight: FontWeight.w400),),

                                            ],),),
                                        ),
                                        SizedBox(height: 20,),
                                        Center(
                                          child: Padding(
                                            padding: const EdgeInsets.only(left: 20,),
                                            child: Container(child: Row(
                                              children: [
                                                Column(children: [
                                                  Text("Protien",style:TextStyle(fontSize: 16,color: Colors.black45)),
                                                  Text("530",style:TextStyle(fontSize: 20,color: Colors.white,fontWeight: FontWeight.bold)),
                                                ],),
                                                SizedBox(width: 10,),
                                                Container(
                                                  width: 2,height: 35,decoration: BoxDecoration(color: Colors.white,),
                                                ),
                                                SizedBox(width: 10,),
                                                Column(children: [
                                                  Text("Fats",style:TextStyle(fontSize: 16,color: Colors.black45)),
                                                  Text("103",style:TextStyle(fontSize: 20,color: Colors.white,fontWeight: FontWeight.bold)),
                                                ],),
                                                SizedBox(width: 10,),
                                                Container(
                                                  width: 2,height: 35,decoration: BoxDecoration(color: Colors.white,),
                                                ),
                                                SizedBox(width: 10,),
                                                Column(children: [
                                                  Text("Carbs",style:TextStyle(fontSize: 16,color: Colors.black45)),
                                                  Text("250",style:TextStyle(fontSize: 20,color: Colors.white,fontWeight: FontWeight.bold)),
                                                ],),
                                              ],
                                            ),),
                                          ),
                                        ),
                                      ],
                                    )
                                    ,),
                                ),
                              ],
                            ),
                          ),


                        ],
                      ),
                      Padding(
                        padding: const EdgeInsets.only(left:80),
                        child: Container(
                          width: 250,
                          height: 35,

                          child: ElevatedButton(onPressed:(){

                          }, child: Text('Add to Dairy',style:TextStyle(color: Colors.black,fontSize: 16,fontWeight: FontWeight.bold, ) ,),
                            style: ElevatedButton.styleFrom(foregroundColor: Colors.black45,primary: Colors.white,shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(10), // Button ke corners ka radius
                            ),),
                          ),
                        ),
                      )
                    ],
                  ),
                ),



              ],
            ),
          ),
        ),
      ),

    );
  }
}
