import 'package:flutter/material.dart';
class resume extends StatelessWidget {
  const resume({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text("Resume",style: TextStyle(color: Colors.brown.shade900,fontWeight: FontWeight.w900),),
          centerTitle: true,
          backgroundColor: Colors.brown.shade100,

          /*actions: [
          Padding(
            padding: const EdgeInsets.only(right: 30.0),
            child: Container(
              width: 30,
              child: Image.asset(
                'assets/images/pic.png',
              ),
            ),
          ),
        ],*/
        ),
      body:SingleChildScrollView

        (
          scrollDirection: Axis.vertical,
          child: Center(child: Image.asset("assets/images/cv.jpeg")))
    );
  }
}
