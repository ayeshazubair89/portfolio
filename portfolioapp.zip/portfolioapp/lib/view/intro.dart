import 'package:flutter/material.dart';
import 'package:portfolioapp/view/home.dart';
//import 'package:google_fonts/google_fonts.dart';
class intro extends StatefulWidget {
  const intro({super.key});

  @override
  State<intro> createState() => _introState();
}

class _introState extends State<intro> {
  @override
  Widget build(BuildContext context) {
    final height=MediaQuery.of(context).size.height*1;
    final width=MediaQuery.of(context).size.width*1;
    return Scaffold(
      appBar: AppBar(
        title: Text("About",style: TextStyle(color: Colors.brown.shade900,fontWeight: FontWeight.w900),),
        centerTitle: true,
        backgroundColor: Colors.brown.shade100,

        /*actions: [
          Padding(
            padding: const EdgeInsets.only(right: 30.0),
            child: Container(
              width: 30,
              child: Image.asset(
                'assets/images/pic.png',
              ),
            ),
          ),
        ],*/
      ),
body: SingleChildScrollView(
  scrollDirection: Axis.vertical,
  child: Container
    ( height: height*1,
    width: width*1,
    decoration: BoxDecoration(color: Colors.brown.shade100    ,
        image: DecorationImage(
            image: AssetImage('assets/images/hti.jpeg'),fit: BoxFit.fitWidth)

    ),
    child:
    SingleChildScrollView(
      scrollDirection: Axis.vertical,
      child: Column(

        children: [



          SingleChildScrollView(
            scrollDirection: Axis.vertical,
            child: Container(
              width: 200,
              height: 200,
              margin:EdgeInsets.only(top:100.0),
              child: Card(
                elevation: 5.0,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(180.0), // This sets the border radius to make it circular
                ),
                child: Container(
                  width: width * 0.6,
                  height: height * 0.4,
                  child: CircleAvatar(
                    backgroundColor: Colors.transparent, // Transparent background to avoid overlapping corners
                    child: ClipOval(
                      child: Image.asset('assets/images/tme.png', fit: BoxFit.cover),
                    ),
                  ),
                ),
              ),
            ),
          ),


          SizedBox(height:20),
          Text("Hello,",style:TextStyle(fontSize: 35,color: Colors.brown.shade900,fontWeight: FontWeight.w900),),
          Text("im Ayesha Zubair,",style:TextStyle(fontSize: 35,color: Colors.brown.shade900,fontWeight: FontWeight.w900),),
          Padding(
            padding: const EdgeInsets.only(left: 20,right: 20,top: 10),
            child: Text("A young and active girl that experienced as a Mobile Developer "
                "more than a year. Someone with strong analytical thinking "
                "ciritical thinking and idea sharing.",style: TextStyle(fontSize: 16,color: Colors.black87),
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(left: 20,right: 20,top: 10),
            child: Text("I'm skilled in Android Development . I have knowledge "
                "to develop applications like Managments Systems, Call Log Filters, Quiz Apps for driving Licenses etc..",
              style: TextStyle(fontSize: 16,color: Colors.black87),),
          ),

          Padding(
            padding: const EdgeInsets.only(top:50),
            child: IconButton(
                icon: Icon(Icons.arrow_circle_right, color: Colors.brown.shade900, size: 50),
                onPressed: () {
                  // Add your onPressed functionality here
                  Navigator.push(context, MaterialPageRoute(builder: (context) => home())); // Corrected
                },
              ),
          ),



          /* Row(children: [
            Expanded(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    width: width*0.4,height: height*0.3,
                    decoration: BoxDecoration(
                      color: Colors.white10,  borderRadius: BorderRadius.only(bottomLeft: Radius.circular(30.0)),
                    ),
                    child: Container(
                      width: width*0.6,height: height*0.5,
                      child:
                      Column(
                        children: [

                        ],
                      ),

                    ),
                  ),


                ],

              ),
            ),
            SizedBox(width: width*0.1, height: height*0.4,),

          ],),*/

        ],
      ),
    ),

  ),
),
    );
  }
}
